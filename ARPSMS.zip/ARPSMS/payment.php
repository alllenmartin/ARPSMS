<?php
require ('includes/ses3.php');
include ('includes/header.php');
include ('nav_bar/navbar.php');
require 'includes/db1.php';
require 'includes/display.php';

if($_SESSION['email'])
  {
$result = mysqli_query($conn, "SELECT * FROM farms F, register_db R,orders O,products P WHERE F.user_id = R.user_id AND R.user_id = O.user_id AND O.product_id = P.product_id ORDER BY O.order_id");
while($row = mysqli_fetch_array($result)){
$phone = $row['phone'];
$phone2 = $row['phone2'];
$total_price = $row['total_price'];

}
    ?>
<?php
}
?>


      
   <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">



            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php

            if (isset($_SESSION['email'])) {
            $sql = "SELECT * FROM register_db WHERE email='".$_SESSION['email']."'";
            $result = mysqli_query($conn,$sql);

            while ($user = mysqli_fetch_object($result)) {
            ?>
            <span class="mr-2 d-none d-lg-inline text-gray-600 small" style="font-weight: bold;"><?php echo $user->first_name; ?>   <?php echo $user->last_name;  ?></span>
            <?php
            }

          }

            ?>

             <?php


          $image = "SELECT file FROM register_db WHERE  email='".$_SESSION['email']."' ";
          $result = mysqli_query($conn,$image);
          $path=mysqli_fetch_assoc($result) or die("Could not fetch array : " .mysqli_error($conn));

            ?>
                <img class="img-profile rounded-circle" src="<?php echo 'includes/image/'.$path['file'];?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
           <h1 class="h3 mb-1 text-gray-800"></h1><br><br>
            <a href="pdf/order_report.php?order_report=<?php echo $_SESSION['email']?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
          </div>



           <div class="row">
             <div class="col-xl-3">
             </div>

            <!-- Area Chart -->
            <div class="col-xl-5">
              <div class="card shadow mb-8">

                <!-- Card Body -->
                <?php
              if(isset($_GET['error']))
              {
              if($_GET['error'] =="amount"){
              echo '<div class="alert alert-danger" role="alert">Payment Is Less/More Than Required!</div>';
              }
              elseif ($_GET['error'] == "success") {
              echo '<div class="alert alert-success" role="alert">Payment Successful!</div>';
              }
              }
              ?>

                <div class="card-body">

                    <div class="row" >
                    <form action="http://machalistingy.co.ke/wordpress/stk_initiate.php" id="to_initiate" method="POST">

                      <label>Payment Type</label>
                      <select>
                        <option>MPESA</option>
                        <option><?php if($status == 0) echo 'disabled';?>Cash on Delivery</option>
                      </select><br><br>
                      <label><i class="fa fa-phone">  </i>  Phone Number</label>
                      <input type="" name="phone" value="<?php echo $phone;?>" class="form-control col-lg-12 col-lg-offset-8" ><br>
                      <label><i class="fa fa-home">  </i> Payable Amount</label>
                      <input type="" name="payable_amount" id="pamt" value="<?php echo $total_price;?>"  class="form-control col-lg-12 col-lg-offset-8" ><br>

                      <label><span class="fa fa-credit-card" >&nbsp;Enter the payable amount in full  <sup class="text-danger">*</sup></span></label>
                      <input type="text" name ="amount" id="amt" placeholder="Enter Transaction Code" class="form-control col-lg-12 col-lg-offset-8" ><br>
                      <div class="col-lg-8">
                      <button class="btn btn-sm btn-success" id="confirm" name="submit_payment" >Submit</button>

                      </div>
                    </form>

                    </div>

                </div>
              </div>
            </div>




        </div>
        <!-- /.container-fluid -->

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php

      include ('includes/footer.php');
      ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>
 

  <?php
include ('includes/script.php');


  ?>

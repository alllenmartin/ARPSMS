<?php
require 'includes/ses2.php';
include ('includes/header.php');
include ('nav_bar/navbar_super.php');
require 'includes/db1.php';
require 'includes/display.php';


?>



       <!-- Begin Page Content -->
       <div class="container-fluid"><br><br>

         <!-- Page Heading -->
         <h1 class="h3 mb-1 text-gray-800">Add Activity</h1><br><br>
<form action="includes/func.php" method="POST">
         <!-- Content Row -->
         <div class="row">

           <!-- Border Left Utilities -->
           <div class="col-lg-3">

           </div>


            <!-- Border Left Utilities -->
           <div class="col-lg-5">
           <div class="card shadow mb-4">
               <div class="card-header py-3">
                 <h6 class="m-0 font-weight-bold text-primary">Update Scheme</h6>
               </div>
               <!-- Display Error Message -->
               <?php
                if(isset($_GET['error']))
                {
                if($_GET['error'] =="successful"){
                echo '<div class="alert alert-success" role="alert">Item Inserted Successfully!</div>';
                }
                elseif ($_GET['error'] == "empty") {
                echo '<div class="alert alert-danger" role="alert">All Fields Must Be Filled</div>';
                }
                elseif ($_GET['error'] == "unsuccessful") {
                echo '<div class="alert alert-danger" role="alert">An error occured.Try Again</div>';
                }
                }
                ?>
               <div class="card-body">
               <label>Administrator</label><br>
               <input type="text" name="author" class="form-control" value="<?php echo  $username; ?>"><br>
              <label>Type Of Activity</label>
              <select type= "text" name="activity">

                     <option value="Farmers General Meeting" >Farmers General Meeting</option>
                     <option value="Farmers Argent Meeting" >Farmers Argent Meeting</option>
                      <option value="Agricultural Visitors Visit" >Agricultural Visitors Visit</option>
                      <option value="Others" >Others</option>
                 </select><br><br>
            <label>Date Of Activity</label>
           <input class="form-control" type="date" name="adate"><br>
           <label>Time Of Activity</label>
          <input class="form-control" type="time" name="atime"><br>
          <label>Venue</label>
              <select type = "text" name="venue">
                     <option value="" >---Select Venue---</option>
                     <?php
                     $sql = "SELECT * FROM scheme ORDER BY scheme_name ASC";
                     $result = mysqli_query($conn,$sql);
                     while($data = mysqli_fetch_array($result)) {
                     ?>
                     <option value="<?php echo $data['scheme_name']; ?>"><?php echo $data['scheme_name']; ?></option>
                     <?php
                     }

                     ?>
                 </select><br><br>
              <button class="btn btn-success btn-sm" name="add_activity" type="add_activity">Submit</button>
               </div>
             </div>
           </div>

            <!-- Border Left Utilities -->
           <div class="col-lg-4">

           </div>



         </div>

     </form>

       </div>
       <!-- /.container-fluid -->

     </div>
     <!-- End of Main Content -->

     <!-- Footer -->
     <?php include_once ('includes/footer.php');?>
     <!-- End of Footer -->
</body>
<?php include ('includes/script.php');
?>
</html>
<!-- <script src="js/Vendor/jquery.min.js"></script> -->
<script src="js/inputmask.js"></script>

  <script src="js/jquery.inputmask.js"></script>

<script>

$(document).ready(function(){
//input masking
    $('#phone').inputmask("99999999");
});
</script>

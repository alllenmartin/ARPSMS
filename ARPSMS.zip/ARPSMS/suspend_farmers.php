<?php
require ('includes/ses2.php');
include ('includes/header.php');
include ('nav_bar/navbar_super.php');
require 'includes/db1.php';
require 'includes/display.php';




?>



       <!-- Begin Page Content -->
       <div class="container-fluid"><br><br>

         <!-- Page Heading -->
         <h1 class="h3 mb-1 text-gray-800">Confirm Supervisor</h1><br><br>


<form action="includes/update.php" method="POST">
         <!-- Content Row -->
         <div class="row">

           <!-- Border Left Utilities -->
           <div class="col-lg-3">

           </div>


            <!-- Border Left Utilities -->
           <div class="col-lg-5">
           <div class="card shadow mb-4">
               <div class="card-header py-3">
                 <h6 class="m-0 font-weight-bold text-primary">Confirm Supervisor</h6>
               </div>
               <div class="card-body">
              <label>Email Address</label>
           <input class="card mb-4 py-3 border-bottom-success form-control" type="text" name="email" value="<?php echo $email;?>"><br>
           
            <label>Phone Number</label>
           <input class="card mb-4 py-3 border-bottom-success form-control" type="text"  value="<?php echo $phone;?>"><br>
            <label>First Number</label>
           <input class="card mb-4 py-3 border-bottom-success form-control" type="text"  value="<?php echo $fnumber;?>"><br>
            <label>Firm Size </label>
           <input class="card mb-4 py-3 border-bottom-success form-control" type="text" value="<?php echo $farm_size;?>"><br>
            
           <label>Action</label>
           <select border-bottom-success placeholder="Select supervisor..." name="isSuspended">
           <option value="0">Suspend</option>
          
              </select><br><br>

              <button class="btn btn-success btn-sm" name="suspend_farmer" type="update_scheme">Submit</button>
               </div>
             </div>
           </div>

            <!-- Border Left Utilities -->
           <div class="col-lg-4">

           </div>



         </div>

     </form>

       </div>
       <!-- /.container-fluid -->

     </div>
     <!-- End of Main Content -->

     <!-- Footer -->
     <?php include_once ('includes/footer.php');?>
     <!-- End of Footer -->
</body>
<?php include ('includes/script.php');
?>
</html>
<!-- <script src="js/Vendor/jquery.min.js"></script> -->
<script src="js/inputmask.js"></script>

  <script src="js/jquery.inputmask.js"></script>

<script>

$(document).ready(function(){
//input masking
    $('#phone').inputmask("99999999");
});
</script>

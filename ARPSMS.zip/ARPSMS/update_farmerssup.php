<?php

// Delete Farmers

require 'includes/db1.php';
if(isset($_GET['dfarmers'])) {
$dfarmers=$_GET['dfarmers'];
$sql="DELETE FROM farms WHERE farm_id='$dfarmers'  ";
$sql=mysqli_query($conn,$sql);
header('location:my_farmers.php?error=Successful');
exit();
}
else {
header('location:my_farmers.php?error=Unsuccessful');
exit();
}


 ?>

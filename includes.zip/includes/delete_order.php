<?php
//Database connection
require ('db1.php');

if (isset($_GET['dl'])) {
	$dl = $_GET['dl'];

	$sql=mysqli_query($conn,"UPDATE orders SET is_delete = '0' WHERE order_id='$dl'");

	if ($sql) {
		header("Location:../orders_supervisor.php?error=success");
		exit();

	}
	else
	{
		header("Location:../orders_supervisor.php?error=error");
		exit();
	}
}



?>
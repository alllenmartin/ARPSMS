<?php

require ('db1.php');
if (isset($_POST['submit_change'])) {

	$user_id = isset($_GET['user_id']);
	$email = isset($_GET['email']);

	
	$oldpassword = mysqli_real_escape_string($conn,$_POST['oldpassword']);
	$newpassword = mysqli_real_escape_string($conn,$_POST['newpassword']);
	$confirmpassword = mysqli_real_escape_string($conn,$_POST['confirmpassword']);




	$sql = "SELECT * FROM register_db WHERE user_id='$user_id' AND email='$email'";
	$result = mysqli_query($conn,$sql);
	$count = mysqli_num_rows($result);
	$data = mysqli_fetch_array($result);

	$hash = password_hash($password,PASSWORD_DEFAULT);
	$hashed_password = password_verify($password, $hash);
	
	if ($oldpassword <> $hashed_password) {
		header("Location:../password_reset.php?erro=oh");
		exit();
	}
	elseif ($newpassword <> $confirmpassword) {
		header("Location:../password_reset.php?erro=nc");
		exit();
	}else
	{
		$hash1 = password_hash($newpassword,PASSWORD_DEFAULT);

     $update = "UPDATE register_db SET password = '$hash1'";
     $result = mysqli_query($conn,$update);

     if ($result) {
     	header("Location:../login.php?");
		exit();
     }
     else
     {
     	header("Location:../password_reset.php?erro=error");
		exit();
     }
	}


}

//Forgot Password
if (isset($_POST['submit_forgot'])) {

	$user_id = isset($_GET['user_id']);
	$email = isset($_GET['email']);

	
	
	$newpassword = mysqli_real_escape_string($conn,$_POST['newpassword']);
	$confirmpassword = mysqli_real_escape_string($conn,$_POST['confirmpassword']);




	$sql = "SELECT * FROM register_db WHERE user_id='$user_id' AND email='$email'";
	$result = mysqli_query($conn,$sql);
	$count = mysqli_num_rows($result);
	$data = mysqli_fetch_array($result);

	$hash = password_hash($password,PASSWORD_DEFAULT);
	$hashed_password = password_verify($password, $hash);
	
	
	if ($newpassword <> $confirmpassword) {
		header("Location:../password_reset.php?erro=nc");
		exit();
	}else
	{
		$hash1 = password_hash($newpassword,PASSWORD_DEFAULT);

     $update = "UPDATE register_db SET password = '$hash1'";
     $result = mysqli_query($conn,$update);

     if ($result) {
     	header("Location:../login.php?");
		exit();
     }
     else
     {
     	header("Location:../password_reset.php?erro=error");
		exit();
     }
	}


}